# DAT405  Assignment 2

Weather Api




Introduction.

Using research of both Daniel Schiffman and his videos on you tube's coding transition
I implemented what I had learned and added it to information I had found around google/yahoo to
create my own version of a weather Api.


issues.

Unfortunately I decided to settle on remaking a project with the ice cream by unit3finaltask, "https://www.youtube.com/watch?v=YJnTUyNZuyY", I used version v2.

Project went amazing, I had all the stuff I wanted from images to color changes based on weather temp.
after finishing my sketch and feeling very happy.... Yahoo from the 3rd of January decided to pull the API "https://developer.yahoo.com/weather/".  I had spent weeks turning this project into my own with some great features... but it wasn't to be. I did try and contact yahoo for a key but still not heard anything back so decided to move on and start from scratch.

So my project ended up not being what I expected but it works with the API.

Downfall.

I added a class but couldn't get it working Unfortunately, Had the flu just after xmas and through so my thought pattern and energy was at a low.

How does it work.

The project works by entering a city name and based on the search from the api url the if statements based on temperature will return a value with an image and two ellipses.

The first ellipse and the text changes color with the temperature.

The second ellipse changes size based on the temperature, also adds an arrow and text pointing to the temperature.

Found this project harder although it works I'm not happy with it.


conclusion.


All in all learnt a lot. I enjoy the creative coding aspect of the course.

I think the assignment was badly planned with the xmas holidays but still unexpected illness and stress at home didn't help on this occasion.




references


https://editor.p5js.org/eric/sketches/r12_8Zdyg

https://shiffman.net/a2z/data-apis/


https://github.com/jibs23labs/P5-Visualization/issues/1
